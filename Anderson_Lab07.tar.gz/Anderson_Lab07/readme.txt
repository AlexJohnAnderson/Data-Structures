Hello,

		You can execute my maxmin heap implementation by simply making
		executables and then typing './prog data.txt'. Thanks!
Best,
Alex Anderson