#include "Hash.h"
#include <stdexcept>
#include <iostream>

Hash::Hash()
{
	int buckets = 17;
}

Hash::~Hash()
{
    clear();
}

void Hash::clear()
{
	delete []List;
}

int Hash::hashFunc(int entry)
{
	return (entry % buckets)
}

void Hash::insert(int entry)
{
	entry = hashFunc(entry);
}