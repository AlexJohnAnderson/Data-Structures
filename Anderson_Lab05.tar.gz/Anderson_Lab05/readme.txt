Hello, 

	To run my program just use './prog data.txt', this should pull up
	the menu right away. Thanks!

Best,
Alex Anderson.