	Hello, 

		Execution of my code can be done with 
		the command './prog data.txt'. This should 
		immediately pull up a menu with the various
		hash operations. Thanks!
	
	Best,

	Alex Anderson