Hello,

	You can execute part1(Disjoint set) by simply making the
	executables and then typing './prog data.txt'. You can execute
 	part2(Graph) by simply making the executables and then
	typing './prog'. Thanks!
Best,
Alex Anderson