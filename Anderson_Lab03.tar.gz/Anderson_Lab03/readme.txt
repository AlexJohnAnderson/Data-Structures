	Hello, 

		Execution of my code can be done with 
		the command './prog'. This will print
		the results of the three differnt hashing 
		schemes I implemented. It may take several 
		minutes to execute!
	
	Best,

	Alex Anderson